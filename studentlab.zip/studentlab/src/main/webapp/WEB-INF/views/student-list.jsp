<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Φοιτητές</title>
</head>
<body>
    <h1>Φοιτητές</h1>

    <c:choose>
        <c:when test="${empty students}">
            <p>Δεν υπάρχουν φοιτητές ακόμα.</p>
        </c:when>
        <c:otherwise>
            <table border="1">
                <tr>
                    <th>Όνομα</th>
                    <th>Επώνυμο</th>
                    <th>Email</th>
                </tr>
                <c:forEach var="student" items="${students}">
                    <tr>
                        <td><c:out value="${student.name}"/></td>
                        <td><c:out value="${student.surname}"/></td>
                        <td><c:out value="${student.email}"/></td>
                    </tr>
                </c:forEach>
            </table>
        </c:otherwise>
    </c:choose>

    <p><a href="${pageContext.request.contextPath}/students/new">Νέος φοιτητής</a></p>
</body>
</html>
