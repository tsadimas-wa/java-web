package gr.uniwa.ice.studentlab.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class Student {

    private String name;
    private String surname;
    private String email;

    public Student(String name, String surname, String email) {
        this.name = name;
        this.surname = surname;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getEmail() {
        return email;
    }

    // Επιστρέφει τα λάθη: κλειδί = όνομα πεδίου, τιμή = μήνυμα.
    // Άδειο Map σημαίνει ότι ο φοιτητής είναι έγκυρος.
    public Map<String, String> validate() {
        Map<String, String> errors = new LinkedHashMap<>();

        if (isBlank(name)) {
            errors.put("name", "Το όνομα είναι υποχρεωτικό.");
        } else if (name.length() < 2) {
            errors.put("name", "Το όνομα πρέπει να έχει τουλάχιστον 2 χαρακτήρες.");
        }

        if (isBlank(surname)) {
            errors.put("surname", "Το επώνυμο είναι υποχρεωτικό.");
        }

        if (isBlank(email)) {
            errors.put("email", "Το email είναι υποχρεωτικό.");
        } else if (!email.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
            errors.put("email", "Μη έγκυρο email.");
        }

        return errors;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
