package gr.uniwa.ice.studentlab.repository;

import gr.uniwa.ice.studentlab.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentRepository {

    // Μία λίστα για όλη την εφαρμογή (static). Χάνεται όταν σταματήσει ο Tomcat.
    private static final List<Student> students = new ArrayList<>();

    // synchronized: πολλά requests μπορεί να έρθουν ταυτόχρονα,
    // οπότε μόνο ένα τη φορά επιτρέπεται να πειράζει τη λίστα.
    public static synchronized void save(Student student) {
        students.add(student);
    }

    public static synchronized List<Student> findAll() {
        return new ArrayList<>(students);   // αντίγραφο, για να μην αλλάζει η λίστα απ' έξω
    }
}
