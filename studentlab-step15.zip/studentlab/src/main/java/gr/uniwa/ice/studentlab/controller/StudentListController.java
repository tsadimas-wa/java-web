package gr.uniwa.ice.studentlab.controller;

import gr.uniwa.ice.studentlab.model.Student;
import gr.uniwa.ice.studentlab.repository.StudentRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/students")
public class StudentListController extends HttpServlet {

    // GET /students → εμφάνιση όλων των φοιτητών
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Παίρνουμε τα δεδομένα από το repository
        List<Student> students = StudentRepository.findAll();

        // 2. Τα «δίνουμε» στη JSP ως attribute του request
        request.setAttribute("students", students);

        // 3. Forward στη JSP, που θα φτιάξει το HTML
        request.getRequestDispatcher("/WEB-INF/views/student-list.jsp").forward(request, response);
    }
}
