package gr.uniwa.ice.studentlab.controller;

import gr.uniwa.ice.studentlab.model.Student;
import gr.uniwa.ice.studentlab.repository.StudentRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/students/*")
public class StudentViewController extends HttpServlet {

    // GET /students/21390001 → η σελίδα του φοιτητή με ΑΜ 21390001
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Το path variable: για το /students/21390001 η getPathInfo() δίνει "/21390001"
        String pathInfo = request.getPathInfo();
        String amText = (pathInfo == null) ? null : pathInfo.substring(1);   // πετάμε το αρχικό "/" → "21390001"
        Integer am = parseIntOrNull(amText);                                  // "21390001" → 21390001

        // 2. Βρίσκουμε τον φοιτητή με αυτόν τον ΑΜ
        Student student = (am == null) ? null : StudentRepository.findByAm(am);
        if (student == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Δεν βρέθηκε ο φοιτητής.");
            return;
        }

        // 3. Τον δίνουμε στη JSP
        request.setAttribute("student", student);
        request.getRequestDispatcher("/WEB-INF/views/student-view.jsp").forward(request, response);
    }

    // "21390001" → 21390001, ενώ null, "", "abc" → null
    private Integer parseIntOrNull(String value) {
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
