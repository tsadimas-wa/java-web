package gr.uniwa.ice.studentlab.controller;

import gr.uniwa.ice.studentlab.model.Student;
import gr.uniwa.ice.studentlab.repository.StudentRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet("/students/new")
public class StudentFormController extends HttpServlet {

    // GET /students/new → εμφάνιση της κενής φόρμας
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/student-form.jsp").forward(request, response);
    }

    // POST /students/new → ο χρήστης πάτησε «Αποθήκευση»
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Διαβάζουμε τα πεδία και φτιάχνουμε το αντικείμενο.
        //    Ο ΑΜ έρχεται ως String: αν δεν είναι αριθμός, περνάμε 0 και η validate() θα τον απορρίψει.
        Integer am = parseIntOrNull(request.getParameter("am"));
        Student student = new Student(
                trim(request.getParameter("name")),
                trim(request.getParameter("surname")),
                trim(request.getParameter("email")),
                am == null ? 0 : am);

        // 2. Ο έλεγχος των πεδίων γίνεται από την ίδια τη Student
        Map<String, String> errors = student.validate();

        // 3. Ο ΑΜ είναι κλειδί: δεν επιτρέπονται δύο φοιτητές με τον ίδιο
        if (!errors.containsKey("am") && StudentRepository.findByAm(student.getAm()) != null) {
            errors.put("am", "Υπάρχει ήδη φοιτητής με αυτόν τον ΑΜ.");
        }

        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.getRequestDispatcher("/WEB-INF/views/student-form.jsp").forward(request, response);
            return;
        }

        // 4. Αποθήκευση και redirect στη λίστα
        StudentRepository.save(student);
        response.sendRedirect(request.getContextPath() + "/students");
    }

    // "21390001" → 21390001, ενώ null, "", "abc" → null
    private Integer parseIntOrNull(String value) {
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // null → "" και κόψιμο κενών στην αρχή/τέλος
    private String trim(String value) {
        return value == null ? "" : value.trim();
    }
}
