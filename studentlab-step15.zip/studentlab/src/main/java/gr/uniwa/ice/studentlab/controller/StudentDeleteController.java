package gr.uniwa.ice.studentlab.controller;

import gr.uniwa.ice.studentlab.repository.StudentRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/students/delete")
public class StudentDeleteController extends HttpServlet {

    // POST /students/delete → διαγραφή του φοιτητή με τον ΑΜ της φόρμας
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Integer am = parseIntOrNull(request.getParameter("am"));
        if (am == null || !StudentRepository.deleteByAm(am)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Δεν βρέθηκε ο φοιτητής.");
            return;
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }

    // "21390001" → 21390001, ενώ null, "", "abc" → null
    private Integer parseIntOrNull(String value) {
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
