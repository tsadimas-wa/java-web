package gr.uniwa.ice.studentlab.controller;

import gr.uniwa.ice.studentlab.model.Student;
import gr.uniwa.ice.studentlab.repository.StudentRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet("/students/edit")
public class StudentEditController extends HttpServlet {

    // GET /students/edit?am=21390001 → η φόρμα, γεμάτη με τα τρέχοντα στοιχεία
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Student student = findStudent(request);
        if (student == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Δεν βρέθηκε ο φοιτητής.");
            return;
        }
        request.setAttribute("student", student);
        request.getRequestDispatcher("/WEB-INF/views/student-edit.jsp").forward(request, response);
    }

    // POST /students/edit → ο χρήστης πάτησε «Αποθήκευση αλλαγών»
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Student existing = findStudent(request);
        if (existing == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Δεν βρέθηκε ο φοιτητής.");
            return;
        }

        // 1. Νέο αντικείμενο με τις τιμές της φόρμας και τον ίδιο ΑΜ
        Student student = new Student(
                trim(request.getParameter("name")),
                trim(request.getParameter("surname")),
                trim(request.getParameter("email")),
                existing.getAm());

        // 2. Έλεγχος, όπως στο βήμα 14
        Map<String, String> errors = student.validate();
        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.setAttribute("student", student);   // ό,τι έγραψε ο χρήστης, για να μη χαθεί
            request.getRequestDispatcher("/WEB-INF/views/student-edit.jsp").forward(request, response);
            return;
        }

        // 3. Αντικατάσταση και redirect στη σελίδα του φοιτητή (Post/Redirect/Get)
        StudentRepository.update(student);
        response.sendRedirect(request.getContextPath() + "/students/" + student.getAm());
    }

    // Διαβάζει τον ΑΜ (από το ?am=... ή από το κρυφό πεδίο της φόρμας) και βρίσκει τον φοιτητή
    private Student findStudent(HttpServletRequest request) {
        Integer am = parseIntOrNull(request.getParameter("am"));
        return (am == null) ? null : StudentRepository.findByAm(am);
    }

    // "21390001" → 21390001, ενώ null, "", "abc" → null
    private Integer parseIntOrNull(String value) {
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String trim(String value) {
        return value == null ? "" : value.trim();
    }
}
