package gr.uniwa.ice.studentlab.repository;

import gr.uniwa.ice.studentlab.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentRepository {

    private static final List<Student> students = new ArrayList<>();

    public static synchronized void save(Student student) {
        students.add(student);
    }

    public static synchronized List<Student> findAll() {
        return new ArrayList<>(students);
    }

    // Επιστρέφει τον φοιτητή με αυτόν τον ΑΜ, ή null αν δεν υπάρχει
    public static synchronized Student findByAm(int am) {
        for (Student student : students) {
            if (student.getAm() == am) {
                return student;
            }
        }
        return null;
    }

    // Αντικαθιστά τον φοιτητή που έχει τον ίδιο ΑΜ. Επιστρέφει false αν δεν βρέθηκε.
    public static synchronized boolean update(Student student) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getAm() == student.getAm()) {
                students.set(i, student);
                return true;
            }
        }
        return false;
    }

    // Σβήνει τον φοιτητή με αυτόν τον ΑΜ. Επιστρέφει false αν δεν βρέθηκε.
    public static synchronized boolean deleteByAm(int am) {
        return students.removeIf(student -> student.getAm() == am);
    }
}
