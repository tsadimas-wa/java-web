<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Φοιτητής</title>
</head>
<body>
    <h1><c:out value="${student.name}"/> <c:out value="${student.surname}"/></h1>
    <p>ΑΜ: <c:out value="${student.am}"/></p>
    <p>Email: <c:out value="${student.email}"/></p>

    <div>
        <a href="${pageContext.request.contextPath}/students/edit?am=${student.am}">Επεξεργασία</a>
        <form method="post" action="${pageContext.request.contextPath}/students/delete"
              style="display: inline"
              onsubmit="return confirm('Να διαγραφεί ο φοιτητής;');">
            <input type="hidden" name="am" value="${student.am}">
            <button type="submit">Διαγραφή</button>
        </form>
    </div>

    <p><a href="${pageContext.request.contextPath}/students">Λίστα φοιτητών</a></p>
</body>
</html>
