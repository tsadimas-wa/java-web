<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Νέος φοιτητής</title>
</head>
<body>
    <h1>Νέος φοιτητής</h1>

    <c:if test="${not empty errors}">
        <p><strong>Διορθώστε τα λάθη της φόρμας.</strong></p>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/students/new">
        <p>
            <label for="name">Όνομα:</label>
            <input type="text" id="name" name="name" value="<c:out value='${param.name}'/>">
            <strong><c:out value="${errors.name}"/></strong>
        </p>
        <p>
            <label for="surname">Επώνυμο:</label>
            <input type="text" id="surname" name="surname" value="<c:out value='${param.surname}'/>">
            <strong><c:out value="${errors.surname}"/></strong>
        </p>
        <p>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<c:out value='${param.email}'/>">
            <strong><c:out value="${errors.email}"/></strong>
        </p>
        <p>
            <label for="am">ΑΜ:</label>
            <input type="text" id="am" name="am" value="<c:out value='${param.am}'/>">
            <strong><c:out value="${errors.am}"/></strong>
        </p>
        <p>
            <button type="submit">Αποθήκευση</button>
        </p>
    </form>

    <p><a href="${pageContext.request.contextPath}/students">Λίστα φοιτητών</a></p>
</body>
</html>
