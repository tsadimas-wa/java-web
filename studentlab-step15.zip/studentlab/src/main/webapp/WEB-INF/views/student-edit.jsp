<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Επεξεργασία φοιτητή</title>
</head>
<body>
    <h1>Επεξεργασία φοιτητή</h1>

    <c:if test="${not empty errors}">
        <p><strong>Διορθώστε τα λάθη της φόρμας.</strong></p>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/students/edit">
        <input type="hidden" name="am" value="${student.am}">
        <p>ΑΜ: <c:out value="${student.am}"/></p>
        <p>
            <label for="name">Όνομα:</label>
            <input type="text" id="name" name="name" value="<c:out value='${student.name}'/>">
            <strong><c:out value="${errors.name}"/></strong>
        </p>
        <p>
            <label for="surname">Επώνυμο:</label>
            <input type="text" id="surname" name="surname" value="<c:out value='${student.surname}'/>">
            <strong><c:out value="${errors.surname}"/></strong>
        </p>
        <p>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<c:out value='${student.email}'/>">
            <strong><c:out value="${errors.email}"/></strong>
        </p>
        <p>
            <button type="submit">Αποθήκευση αλλαγών</button>
        </p>
    </form>

    <p><a href="${pageContext.request.contextPath}/students/${student.am}">Άκυρο, πίσω στον φοιτητή</a></p>
</body>
</html>
